int double_input(int input) {
    return input * 2;
}
