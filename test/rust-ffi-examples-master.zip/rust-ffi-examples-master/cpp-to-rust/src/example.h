#ifndef _EXAMPLE_H
#define _EXAMPLE_H

#ifdef __cplusplus
extern "C"{
#endif

int double_input(int input);

#ifdef __cplusplus
}
#endif
#endif
